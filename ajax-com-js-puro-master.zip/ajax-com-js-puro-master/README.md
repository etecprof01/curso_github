# Ajax com JS puro
Projeto criado para exemplicar requisições AJAX com Javascript puro

Criado para exemplificar requisições Ajax no post feito para o meu [blog](http://blog.matheuscastiglioni.com.br)

Post: [Preenchendo formulário HTML automaticamente com AJAX](http://blog.matheuscastiglioni.com.br/requisicoes-ajax-com-javascript)
